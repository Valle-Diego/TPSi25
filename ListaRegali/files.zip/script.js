(function(){

  const CREATOR_PASSWORD = 'Pinolo2026!';

  const GIFTS_KEY = 'gift-list:gifts';
  const CLAIMS_KEY = 'gift-list:claims';
  const ROLE_KEY = 'gift-list:role';
  const NAME_KEY = 'gift-list:friend-name';
  const WANTLIST_KEY = 'gift-list:music-wantlist';
  const COLLECTION_KEY = 'gift-list:music-collection';
  const DISCOGS_USER_KEY = 'gift-list:discogs-user';
  const DISCOGS_TOKEN_KEY = 'gift-list:discogs-token';

  let role = null;
  let friendName = '';
  let gifts = [];
  let claims = {};
  let wantlist = [];
  let collection = [];
  let currentPref = 0;
  let friendSortValue = 'default';
  let editingGiftId = null;

  const $ = (id) => document.getElementById(id);

  function uid(){ return 'g' + Date.now().toString(36) + Math.random().toString(36).slice(2,7); }

  /* ---- 1b. Configurazione Firebase ---- */
  const firebaseConfig = {
    apiKey: "INCOLLA_QUI_LA_TUA_API_KEY",
    authDomain: "INCOLLA_QUI.firebaseapp.com",
    projectId: "INCOLLA_QUI_IL_PROJECT_ID",
    storageBucket: "INCOLLA_QUI.appspot.com",
    messagingSenderId: "INCOLLA_QUI",
    appId: "INCOLLA_QUI"
  };
  const FIRESTORE_COLLECTION = 'gift-list';

  let db = null;
  try{
    if(firebaseConfig.apiKey && !firebaseConfig.apiKey.startsWith('INCOLLA')){
      firebase.initializeApp(firebaseConfig);
      db = firebase.firestore();
    }
  }catch(e){
    console.error('Firebase non inizializzato:', e);
    db = null;
  }

  /* ---- 2. Helper di storage ---- */

  async function safeGet(key, shared){
    try{
      if(shared){
        if(!db) return null;
        const snap = await db.collection(FIRESTORE_COLLECTION).doc(key).get();
        return snap.exists ? snap.data().value : null;
      }
      return localStorage.getItem(key);
    }catch(e){
      console.error('storage get failed', key, e);
      return null;
    }
  }
  async function safeSet(key, value, shared){
    try{
      if(shared){
        if(!db) return null;
        await db.collection(FIRESTORE_COLLECTION).doc(key).set({ value, updatedAt: Date.now() });
        return true;
      }
      localStorage.setItem(key, value);
      return true;
    }catch(e){
      console.error('storage set failed', key, e);
      return null;
    }
  }

  async function loadRole(){
    const r = await safeGet(ROLE_KEY, false);
    if(r) role = r;
    const n = await safeGet(NAME_KEY, false);
    if(n) friendName = n;
  }

  async function loadGifts(){
    const raw = await safeGet(GIFTS_KEY, true);
    gifts = raw ? JSON.parse(raw) : [];
  }
  async function saveGifts(){
    const res = await safeSet(GIFTS_KEY, JSON.stringify(gifts), true);
    return res !== null;
  }
  async function loadClaims(){
    const raw = await safeGet(CLAIMS_KEY, true);
    claims = raw ? JSON.parse(raw) : {};
  }
  async function saveClaims(){
    await safeSet(CLAIMS_KEY, JSON.stringify(claims), true);
  }

  async function loadMusic(){
    const w = await safeGet(WANTLIST_KEY, true);
    wantlist = w ? JSON.parse(w) : [];
    const c = await safeGet(COLLECTION_KEY, true);
    collection = c ? JSON.parse(c) : [];
  }
  async function saveMusic(){
    await safeSet(WANTLIST_KEY, JSON.stringify(wantlist), true);
    await safeSet(COLLECTION_KEY, JSON.stringify(collection), true);
  }
  async function loadDiscogsCreds(){
    const u = await safeGet(DISCOGS_USER_KEY, false);
    const t = await safeGet(DISCOGS_TOKEN_KEY, false);
    if(u) $('discogsUser').value = u;
    if(t) $('discogsToken').value = t;
  }

  function escapeHtml(s){
    return (s || '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  }

  function setStarWidget(el, value){
    el.dataset.value = value;
    el.querySelectorAll('.star').forEach(btn => {
      btn.classList.toggle('filled', Number(btn.dataset.val) <= value);
    });
  }

  function renderPrefDisplay(pref){
    if(!pref) return '';
    let out = '<div class="pref-display">';
    for(let i = 1; i <= 5; i++){
      out += `<span class="${i <= pref ? 'filled' : ''}">★</span>`;
    }
    out += '</div>';
    return out;
  }

  function renderPriceTag(price){
    if(price === null || price === undefined || price === '') return '';
    return `<span class="price-tag">€ ${Number(price).toFixed(2)}</span>`;
  }

  function sortGiftsForFriend(list){
    const arr = list.slice();
    if(friendSortValue === 'pref-desc'){
      arr.sort((a,b) => (b.pref || 0) - (a.pref || 0));
    } else if(friendSortValue === 'price-asc'){
      arr.sort((a,b) => (a.price ?? Infinity) - (b.price ?? Infinity));
    } else if(friendSortValue === 'price-desc'){
      arr.sort((a,b) => (b.price ?? -Infinity) - (a.price ?? -Infinity));
    }
    return arr;
  }

  /* ---- 3. Import musica: Discogs API + parsing CSV ---- */

  function parseCsv(text){
    const rows = [];
    let row = [], field = '', inQuotes = false;
    for(let i = 0; i < text.length; i++){
      const c = text[i];
      if(inQuotes){
        if(c === '"'){
          if(text[i+1] === '"'){ field += '"'; i++; }
          else inQuotes = false;
        } else field += c;
      } else {
        if(c === '"') inQuotes = true;
        else if(c === ','){ row.push(field); field = ''; }
        else if(c === '\n' || c === '\r'){
          if(field !== '' || row.length){ row.push(field); rows.push(row); row = []; field = ''; }
          if(c === '\r' && text[i+1] === '\n') i++;
        } else field += c;
      }
    }
    if(field !== '' || row.length){ row.push(field); rows.push(row); }
    if(rows.length === 0) return [];
    const headers = rows[0].map(h => h.trim().toLowerCase());
    const idx = (name) => headers.indexOf(name);
    const iArtist = idx('artist');
    const iTitle = idx('title');
    const iFormat = idx('format');
    const iYear = idx('released');
    const iReleaseId = idx('release_id');
    return rows.slice(1).filter(r => r.length > 1).map(r => ({
      artist: iArtist > -1 ? (r[iArtist] || '').trim() : '',
      title: iTitle > -1 ? (r[iTitle] || '').trim() : '',
      format: iFormat > -1 ? (r[iFormat] || '').trim() : '',
      year: iYear > -1 ? (r[iYear] || '').trim() : '',
      releaseId: iReleaseId > -1 ? (r[iReleaseId] || '').trim() : ''
    })).filter(item => item.title);
  }

  // Id stabile tra un'importazione e l'altra: se conosciamo il release_id di
  // Discogs lo usiamo direttamente (così un reimport non perde prezzi/claim),
  // altrimenti ricadiamo su un hash di artista+titolo.
  function hashId(prefix, item, index){
    if(item.releaseId) return prefix + item.releaseId;
    const base = `${item.artist}-${item.title}-${index}`;
    let h = 0;
    for(let i = 0; i < base.length; i++){ h = ((h << 5) - h + base.charCodeAt(i)) | 0; }
    return prefix + Math.abs(h);
  }

  async function fetchDiscogsList(username, token, kind){
    const base = kind === 'collection'
      ? `https://api.discogs.com/users/${encodeURIComponent(username)}/collection/folders/0/releases`
      : `https://api.discogs.com/users/${encodeURIComponent(username)}/wants`;
    let items = [];
    let page = 1;
    const maxPages = 5;
    while(page <= maxPages){
      const res = await fetch(`${base}?token=${encodeURIComponent(token)}&per_page=100&page=${page}`);
      if(!res.ok) throw new Error('HTTP ' + res.status);
      const data = await res.json();
      const releases = kind === 'collection' ? data.releases : data.wants;
      if(!releases || releases.length === 0) break;
      releases.forEach(r => {
        const info = r.basic_information;
        if(!info) return;
        items.push({
          id: (kind === 'collection' ? 'c-' : 'w-') + r.id,
          releaseId: r.id,
          artist: (info.artists && info.artists[0] && info.artists[0].name) || '',
          title: info.title || '',
          year: info.year || '',
          format: (info.formats && info.formats[0] && info.formats[0].name) || ''
        });
      });
      const pages = data.pagination ? data.pagination.pages : 1;
      if(page >= pages) break;
      page++;
    }
    return items;
  }

  /* ---- 4. Rendering: regali (creatore / amico) ---- */

  function renderCreator(){
    const ul = $('creatorGiftList');
    if(gifts.length === 0){
      ul.innerHTML = '<div class="empty">Non hai ancora aggiunto regali. Scrivine uno qui sopra per iniziare la tua lista.</div>';
      return;
    }
    ul.innerHTML = gifts.map((g, idx) => {
      if(g.id === editingGiftId) return editGiftRowHtml(g);
      return `
      <li>
        <div class="gift-main">
          <p class="gift-name">${escapeHtml(g.name)}</p>
          ${g.note ? `<p class="gift-note">${escapeHtml(g.note)}</p>` : ''}
          ${g.link ? `<a class="gift-link" href="${escapeHtml(g.link)}" target="_blank" rel="noopener">Vedi il link</a>` : ''}
          <div class="gift-meta">${renderPriceTag(g.price)}${renderPrefDisplay(g.pref)}</div>
        </div>
        <div class="gift-side">
          <div class="order-btns">
            <button class="arrow-btn" data-up="${g.id}" ${idx === 0 ? 'disabled' : ''}>▲</button>
            <button class="arrow-btn" data-down="${g.id}" ${idx === gifts.length - 1 ? 'disabled' : ''}>▼</button>
          </div>
          <button class="del-btn" data-edit="${g.id}">modifica</button>
          <button class="del-btn" data-id="${g.id}">rimuovi</button>
        </div>
      </li>`;
    }).join('');

    ul.querySelectorAll('.del-btn[data-id]').forEach(btn => {
      btn.addEventListener('click', async () => {
        gifts = gifts.filter(g => g.id !== btn.dataset.id);
        await saveGifts();
        renderCreator();
      });
    });
    ul.querySelectorAll('[data-edit]').forEach(btn => {
      btn.addEventListener('click', () => {
        editingGiftId = btn.dataset.edit;
        renderCreator();
      });
    });
    ul.querySelectorAll('[data-up]').forEach(btn => {
      btn.addEventListener('click', async () => {
        moveGift(btn.dataset.up, -1);
        await saveGifts();
        renderCreator();
      });
    });
    ul.querySelectorAll('[data-down]').forEach(btn => {
      btn.addEventListener('click', async () => {
        moveGift(btn.dataset.down, 1);
        await saveGifts();
        renderCreator();
      });
    });

    if(editingGiftId){
      const editEl = $('editStars-' + editingGiftId);
      if(editEl){
        editEl.querySelectorAll('.star').forEach(btn => {
          btn.addEventListener('click', () => {
            const val = Number(btn.dataset.val);
            const current = Number(editEl.dataset.value);
            setStarWidget(editEl, val === current ? 0 : val);
          });
        });
      }
      $('editSave-' + editingGiftId).addEventListener('click', async () => {
        const g = gifts.find(x => x.id === editingGiftId);
        if(!g) return;
        const name = $('editName-' + g.id).value.trim();
        if(!name) return;
        g.name = name;
        g.note = $('editNote-' + g.id).value.trim();
        g.link = $('editLink-' + g.id).value.trim();
        const priceRaw = $('editPrice-' + g.id).value.trim();
        g.price = priceRaw === '' ? null : Math.max(0, parseFloat(priceRaw));
        g.pref = Number($('editStars-' + g.id).dataset.value);
        editingGiftId = null;
        await saveGifts();
        renderCreator();
      });
      $('editCancel-' + editingGiftId).addEventListener('click', () => {
        editingGiftId = null;
        renderCreator();
      });
    }
  }

  function starsHtml(idAttr, value){
    let out = `<div class="stars" id="${idAttr}" data-value="${value}">`;
    for(let i = 1; i <= 5; i++){
      out += `<button type="button" class="star${i <= value ? ' filled' : ''}" data-val="${i}">★</button>`;
    }
    out += '</div>';
    return out;
  }

  function editGiftRowHtml(g){
    return `
      <li class="edit-row">
        <div class="gift-main">
          <input type="text" id="editName-${g.id}" value="${escapeHtml(g.name)}" maxlength="80">
          <textarea id="editNote-${g.id}" rows="2" maxlength="200">${escapeHtml(g.note || '')}</textarea>
          <input type="text" id="editLink-${g.id}" value="${escapeHtml(g.link || '')}" maxlength="300" placeholder="Link (facoltativo)">
          <input type="number" id="editPrice-${g.id}" value="${g.price ?? ''}" min="0" step="0.01" placeholder="Prezzo € (facoltativo)">
          <div class="stars-row">
            <span class="stars-label">Preferenza</span>
            ${starsHtml('editStars-' + g.id, g.pref || 0)}
          </div>
          <div class="edit-actions">
            <button class="btn btn-gold" id="editSave-${g.id}">Salva</button>
            <button class="btn btn-ghost" id="editCancel-${g.id}">Annulla</button>
          </div>
        </div>
      </li>`;
  }

  function moveGift(id, dir){
    const idx = gifts.findIndex(g => g.id === id);
    if(idx === -1) return;
    const newIdx = idx + dir;
    if(newIdx < 0 || newIdx >= gifts.length) return;
    const [item] = gifts.splice(idx, 1);
    gifts.splice(newIdx, 0, item);
  }

  function albumLabel(item){
    const parts = [item.artist, item.title].filter(Boolean).join(' — ');
    const meta = [item.format, item.year].filter(Boolean).join(', ');
    return { parts, meta };
  }

  function discogsLink(item){
    return item.releaseId ? `https://www.discogs.com/release/${encodeURIComponent(item.releaseId)}` : '';
  }

  // Un reimport (Discogs o CSV) sostituisce artista/titolo/formato, ma non
  // deve far perdere un prezzo già inserito a mano sullo stesso disco.
  function mergePrices(newItems, oldItems){
    const oldById = {};
    oldItems.forEach(it => { oldById[it.id] = it; });
    return newItems.map(it => ({ ...it, price: oldById[it.id] ? oldById[it.id].price ?? null : null }));
  }

  /* ---- 5. Rendering: musica (creatore / amico) ---- */

  function renderMusicCreator(){
    $('creatorWantlistWrap').style.display = wantlist.length ? 'block' : 'none';
    $('creatorCollectionWrap').style.display = collection.length ? 'block' : 'none';

    $('creatorWantlist').innerHTML = wantlist.map(item => {
      const { parts, meta } = albumLabel(item);
      const link = discogsLink(item);
      return `
        <li>
          <div class="gift-main">
            <p class="gift-name">${escapeHtml(parts)}</p>
            ${meta ? `<p class="music-sub">${escapeHtml(meta)}</p>` : ''}
            ${link ? `<a class="gift-link" href="${link}" target="_blank" rel="noopener">Vedi su Discogs</a>` : ''}
          </div>
          <div class="gift-side">
            <input type="number" class="price-edit" data-price-id="${item.id}" min="0" step="0.01" placeholder="€" value="${item.price ?? ''}">
          </div>
        </li>`;
    }).join('');

    $('creatorCollection').innerHTML = collection.map(item => {
      const { parts, meta } = albumLabel(item);
      const link = discogsLink(item);
      return `
        <li>
          <div class="gift-main">
            <p class="gift-name">${escapeHtml(parts)}</p>
            ${meta ? `<p class="music-sub">${escapeHtml(meta)}</p>` : ''}
            ${link ? `<a class="gift-link" href="${link}" target="_blank" rel="noopener">Vedi su Discogs</a>` : ''}
          </div>
        </li>`;
    }).join('');

    $('creatorWantlist').querySelectorAll('[data-price-id]').forEach(input => {
      input.addEventListener('change', async () => {
        const id = input.dataset.priceId;
        const raw = input.value.trim();
        const price = raw === '' ? null : Math.max(0, parseFloat(raw));
        const item = wantlist.find(w => w.id === id);
        if(item) item.price = price;
        await saveMusic();
      });
    });
  }

  function renderMusicFriend(){
    $('friendWantlistWrap').style.display = wantlist.length ? 'block' : 'none';
    $('friendCollectionWrap').style.display = collection.length ? 'block' : 'none';

    $('friendWantlist').innerHTML = wantlist.map(item => {
      const { parts, meta } = albumLabel(item);
      const link = discogsLink(item);
      const claim = claims[item.id];
      const takenByMe = claim && claim.takenBy === friendName;
      const statusHtml = claim
        ? `<span class="status taken">Preso da ${escapeHtml(claim.takenBy)}</span>`
        : `<span class="status available">Disponibile</span>`;
      let actionBtn = '';
      if(!claim){
        actionBtn = `<button class="btn btn-outline" data-take="${item.id}" style="padding:7px 14px;font-size:0.82rem;">Lo prendo io</button>`;
      } else if(takenByMe){
        actionBtn = `<button class="btn btn-ghost" data-release="${item.id}" style="padding:7px 0;">annulla</button>`;
      }
      return `
        <li>
          <div class="gift-main">
            <p class="gift-name">${escapeHtml(parts)}</p>
            ${meta ? `<p class="music-sub">${escapeHtml(meta)}</p>` : ''}
            ${link ? `<a class="gift-link" href="${link}" target="_blank" rel="noopener">Vedi su Discogs</a>` : ''}
            <div class="gift-meta">${renderPriceTag(item.price)}</div>
          </div>
          <div class="gift-side">${statusHtml}${actionBtn}</div>
        </li>`;
    }).join('');

    $('friendCollection').innerHTML = collection.map(item => {
      const { parts, meta } = albumLabel(item);
      const link = discogsLink(item);
      return `
        <li>
          <div class="gift-main">
            <p class="gift-name">${escapeHtml(parts)}</p>
            ${meta ? `<p class="music-sub">${escapeHtml(meta)}</p>` : ''}
            ${link ? `<a class="gift-link" href="${link}" target="_blank" rel="noopener">Vedi su Discogs</a>` : ''}
          </div>
          <div class="gift-side"><span class="owned-tag">già posseduto</span></div>
        </li>`;
    }).join('');

    $('friendWantlist').querySelectorAll('[data-take]').forEach(btn => {
      btn.addEventListener('click', async () => {
        claims[btn.dataset.take] = { takenBy: friendName, takenAt: Date.now() };
        await saveClaims();
        renderMusicFriend();
      });
    });
    $('friendWantlist').querySelectorAll('[data-release]').forEach(btn => {
      btn.addEventListener('click', async () => {
        delete claims[btn.dataset.release];
        await saveClaims();
        renderMusicFriend();
      });
    });
  }

  function renderFriend(){
    const ul = $('friendGiftList');
    if(gifts.length === 0){
      ul.innerHTML = '<div class="empty">Chi ha creato la lista non ha ancora aggiunto regali. Torna a controllare più tardi.</div>';
      return;
    }
    ul.innerHTML = sortGiftsForFriend(gifts).map(g => {
      const claim = claims[g.id];
      const takenByMe = claim && claim.takenBy === friendName;
      const statusHtml = claim
        ? `<span class="status taken">Preso da ${escapeHtml(claim.takenBy)}</span>`
        : `<span class="status available">Disponibile</span>`;
      let actionBtn = '';
      if(!claim){
        actionBtn = `<button class="btn btn-outline" data-take="${g.id}" style="padding:7px 14px;font-size:0.82rem;">Lo prendo io</button>`;
      } else if(takenByMe){
        actionBtn = `<button class="btn btn-ghost" data-release="${g.id}" style="padding:7px 0;">annulla</button>`;
      }
      return `
        <li>
          <div class="gift-main">
            <p class="gift-name">${escapeHtml(g.name)}</p>
            ${g.note ? `<p class="gift-note">${escapeHtml(g.note)}</p>` : ''}
            ${g.link ? `<a class="gift-link" href="${escapeHtml(g.link)}" target="_blank" rel="noopener">Vedi il link</a>` : ''}
            <div class="gift-meta">${renderPriceTag(g.price)}${renderPrefDisplay(g.pref)}</div>
          </div>
          <div class="gift-side">
            ${statusHtml}
            ${actionBtn}
          </div>
        </li>
      `;
    }).join('');

    ul.querySelectorAll('[data-take]').forEach(btn => {
      btn.addEventListener('click', async () => {
        const id = btn.dataset.take;
        claims[id] = { takenBy: friendName, takenAt: Date.now() };
        await saveClaims();
        renderFriend();
      });
    });
    ul.querySelectorAll('[data-release]').forEach(btn => {
      btn.addEventListener('click', async () => {
        const id = btn.dataset.release;
        delete claims[id];
        await saveClaims();
        renderFriend();
      });
    });
  }

  async function refreshAndRender(){
    await loadGifts();
    await loadMusic();
    if(role === 'creator'){
      renderCreator();
      renderMusicCreator();
    } else if(role === 'friend'){
      await loadClaims();
      renderFriend();
      renderMusicFriend();
    }
  }

  function showApp(){
    $('gate').style.display = 'none';
    $('app').classList.add('show');
    $('firebaseWarning').style.display = db ? 'none' : 'block';
    if(role === 'creator'){
      $('creatorPanel').style.display = 'block';
      $('friendPanel').style.display = 'none';
      $('roleLabel').textContent = 'Stai vedendo la lista come creatore';
    } else {
      $('creatorPanel').style.display = 'none';
      $('friendPanel').style.display = 'block';
      $('roleLabel').textContent = friendName ? `Ciao ${friendName}, stai vedendo la lista come amico` : 'Stai vedendo la lista come amico';
    }
  }

  function showGate(){
    $('app').classList.remove('show');
    $('gate').style.display = 'block';
  }

  // --- gate interactions ---
  /* ---- 6. Gate iniziale (scelta ruolo) e navigazione app ---- */

  $('btnCreator').addEventListener('click', () => {
    $('friendNameForm').classList.remove('show');
    $('creatorPassForm').classList.add('show');
    $('creatorPassInput').focus();
  });

  $('creatorPassConfirm').addEventListener('click', confirmCreator);
  $('creatorPassInput').addEventListener('keydown', (e) => { if(e.key === 'Enter') confirmCreator(); });

  async function confirmCreator(){
    const val = $('creatorPassInput').value;
    if(val !== CREATOR_PASSWORD){
      $('creatorPassError').classList.add('show');
      $('creatorPassInput').focus();
      return;
    }
    $('creatorPassError').classList.remove('show');
    role = 'creator';
    await safeSet(ROLE_KEY, role, false);
    showApp();
    await loadDiscogsCreds();
    await refreshAndRender();
  }

  $('btnFriend').addEventListener('click', () => {
    $('creatorPassForm').classList.remove('show');
    $('friendNameForm').classList.add('show');
    $('friendNameInput').focus();
  });

  $('friendNameConfirm').addEventListener('click', confirmFriend);
  $('friendNameInput').addEventListener('keydown', (e) => { if(e.key === 'Enter') confirmFriend(); });

  async function confirmFriend(){
    const val = $('friendNameInput').value.trim();
    if(!val){ $('friendNameInput').focus(); return; }
    friendName = val;
    role = 'friend';
    await safeSet(ROLE_KEY, role, false);
    await safeSet(NAME_KEY, friendName, false);
    showApp();
    await refreshAndRender();
  }

  $('switchRole').addEventListener('click', () => {
    role = null;
    showGate();
  });

  $('giftPrefStars').querySelectorAll('.star').forEach(btn => {
    btn.addEventListener('click', () => {
      const val = Number(btn.dataset.val);
      const current = Number($('giftPrefStars').dataset.value);
      setStarWidget($('giftPrefStars'), val === current ? 0 : val);
      currentPref = Number($('giftPrefStars').dataset.value);
    });
  });

  /* ---- 7. Listener eventi (form, bottoni, import) ---- */

  $('addGiftBtn').addEventListener('click', async () => {
    const name = $('giftName').value.trim();
    if(!name) { $('giftName').focus(); return; }
    const note = $('giftNote').value.trim();
    const link = $('giftLink').value.trim();
    const priceRaw = $('giftPrice').value.trim();
    const price = priceRaw === '' ? null : Math.max(0, parseFloat(priceRaw));
    const newGift = { id: uid(), name, note, link, price, pref: currentPref, addedAt: Date.now() };
    gifts.push(newGift);
    const status = $('giftFormStatus');
    const ok = await saveGifts();
    if(!ok){
      gifts = gifts.filter(g => g.id !== newGift.id);
      status.classList.add('err');
      status.textContent = 'Salvataggio non riuscito, riprova.';
      renderCreator();
      return;
    }
    status.classList.remove('err');
    status.textContent = 'Regalo salvato e visibile agli amici.';
    $('giftName').value = '';
    $('giftNote').value = '';
    $('giftLink').value = '';
    $('giftPrice').value = '';
    currentPref = 0;
    setStarWidget($('giftPrefStars'), 0);
    renderCreator();
  });

  $('friendSort').addEventListener('change', () => {
    friendSortValue = $('friendSort').value;
    renderFriend();
  });

  $('discogsImportBtn').addEventListener('click', async () => {
    const username = $('discogsUser').value.trim();
    const token = $('discogsToken').value.trim();
    const status = $('discogsStatus');
    if(!username || !token){
      status.textContent = 'Inserisci username e token.';
      status.classList.add('err');
      return;
    }
    const btn = $('discogsImportBtn');
    btn.disabled = true;
    status.classList.remove('err');
    status.textContent = 'Importazione in corso…';
    try{
      await safeSet(DISCOGS_USER_KEY, username, false);
      await safeSet(DISCOGS_TOKEN_KEY, token, false);
      const [newWantlist, newCollection] = await Promise.all([
        fetchDiscogsList(username, token, 'wants'),
        fetchDiscogsList(username, token, 'collection')
      ]);
      wantlist = mergePrices(newWantlist, wantlist);
      collection = newCollection;
      await saveMusic();
      renderMusicCreator();
      status.textContent = `Importati ${newCollection.length} dischi in collezione, ${newWantlist.length} in wantlist.`;
    }catch(e){
      status.classList.add('err');
      status.textContent = 'Importazione non riuscita. Controlla username e token (il browser potrebbe bloccare la richiesta a Discogs).';
    }finally{
      btn.disabled = false;
    }
  });

  function readFileAsText(file){
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = () => resolve(reader.result);
      reader.onerror = reject;
      reader.readAsText(file);
    });
  }

  $('csvCollectionFile').addEventListener('change', async (e) => {
    const file = e.target.files[0];
    if(!file) return;
    const status = $('csvStatus');
    try{
      const text = await readFileAsText(file);
      const parsed = parseCsv(text);
      collection = parsed.map((item, i) => ({ ...item, id: hashId('c-', item, i) }));
      await saveMusic();
      renderMusicCreator();
      status.classList.remove('err');
      status.textContent = `Importati ${collection.length} dischi in collezione dal CSV.`;
    }catch(err){
      status.classList.add('err');
      status.textContent = 'Il file CSV non è leggibile.';
    }
  });

  $('csvWantlistFile').addEventListener('change', async (e) => {
    const file = e.target.files[0];
    if(!file) return;
    const status = $('csvStatus');
    try{
      const text = await readFileAsText(file);
      const parsed = parseCsv(text);
      const withIds = parsed.map((item, i) => ({ ...item, id: hashId('w-', item, i) }));
      wantlist = mergePrices(withIds, wantlist);
      await saveMusic();
      renderMusicCreator();
      status.classList.remove('err');
      status.textContent = `Importati ${wantlist.length} dischi in wantlist dal CSV.`;
    }catch(err){
      status.classList.add('err');
      status.textContent = 'Il file CSV non è leggibile.';
    }
  });

  /* ---- 8. Avvio app ---- */
  // --- init ---
  (async function init(){
    await loadRole();
    await loadGifts();
    await loadMusic();
    if(role === 'creator' || role === 'friend'){
      if(role === 'friend'){
        await loadClaims();
        showApp();
        renderFriend();
        renderMusicFriend();
      } else {
        showApp();
        await loadDiscogsCreds();
        renderCreator();
        renderMusicCreator();
      }
    } else {
      showGate();
    }

    // light polling so everyone stays in sync without a manual refresh
    setInterval(() => {
      if(role) refreshAndRender();
    }, 4000);
  })();
})();
